SELECT "Education" as "Уровень образования", 
COUNT("Customer ID") as "Количество клиентов", 
ROUND(AVG("IQ"), 2) as "Средний уровень IQ"

FROM "walmart_edu fb"
GROUP BY  "Education"
ORDER BY "Количество клиентов" DESC
