SELECT h."Customer ID", h."Main Hobby", e."Education", e."IQ" FROM "walmart hobby fb" h
INNER JOIN "walmart_edu fb" e ON h."Customer ID" = e."Customer ID"